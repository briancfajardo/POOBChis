package presentation;

import javax.swing.*;
import java.awt.*;

public class POOBChisGameGUI extends JFrame {
    GridBagLayout grid;
    public POOBChisGameGUI(){
        super("POOBChisGame");
        prepareElements();
    }
    public void prepareElements(){
        grid = new GridBagLayout();
        setLayout(grid);
        setSize(900,900);
        crearPanel();
        setVisible(true);

    }
    public void crearPanel(){
        GridBagConstraints constraints = new GridBagConstraints();
        JPanel panel = new JPanel();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        constraints.gridheight = 2;
        grid.setConstraints(panel, constraints);
        setLayout(grid);
    }



}


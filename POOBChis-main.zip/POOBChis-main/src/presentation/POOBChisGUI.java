package presentation;

public class POOBChisGUI {
    public POOBChisGUI(){

    }
    public static void main (String args[]){
        POOBChisGameGUI juego = new POOBChisGameGUI();
    }
}

package presentation;

public class UNU {
    public UNU(){
        System.out.println("Unuu");
    }
    //Camilin a veces es mala persona con la pobre Andrea
    //Guacala :)
}

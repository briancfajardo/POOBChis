package domain;

import presentation.UNU;

public class prueba {
    public prueba(){
        System.out.println("Holi");
    }
    public static void main (String args[]){

    }
}
